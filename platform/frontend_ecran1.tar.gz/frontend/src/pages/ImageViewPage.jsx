/**
 * ImageViewPage.jsx — Écran 2 (Prompt 7.2)
 * Placeholder — sera implémenté dans le prochain prompt
 */

import React from "react";
import { useParams, Link } from "react-router-dom";

export default function ImageViewPage() {
  const { imageId } = useParams();

  return (
    <div style={{
      minHeight: "100vh",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      background: "#0b0f14",
      color: "#e8ecf1",
      fontFamily: "'DM Sans', system-ui, sans-serif",
      gap: "1rem",
    }}>
      <h1 style={{ fontSize: "1.5rem", fontWeight: 600 }}>
        Vue par Image — {imageId === "browse" ? "Navigation" : `Image #${imageId}`}
      </h1>
      <p style={{ color: "#8899aa", fontSize: "0.9rem" }}>
        Cet écran sera implémenté au Prompt 7.2
      </p>
      <Link to="/" style={{
        color: "#3d7aed",
        textDecoration: "none",
        fontSize: "0.88rem",
        fontWeight: 500,
      }}>
        ← Retour à la sélection
      </Link>
    </div>
  );
}
