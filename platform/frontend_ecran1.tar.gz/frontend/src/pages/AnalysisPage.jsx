/**
 * AnalysisPage.jsx — Écran 3 (Prompt 7.3)
 * Placeholder — sera implémenté dans un prochain prompt
 */

import React from "react";
import { Link, useSearchParams } from "react-router-dom";

export default function AnalysisPage() {
  const [searchParams] = useSearchParams();

  const filters = {
    category: searchParams.get("category") || "Toutes",
    vlm_name: searchParams.get("vlm_name") || "Comparaison",
    compression_type: searchParams.get("compression_type") || "baseline",
    compression_level: searchParams.get("compression_level"),
  };

  return (
    <div style={{
      minHeight: "100vh",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      background: "#0b0f14",
      color: "#e8ecf1",
      fontFamily: "'DM Sans', system-ui, sans-serif",
      gap: "1rem",
      padding: "2rem",
    }}>
      <h1 style={{ fontSize: "1.5rem", fontWeight: 600 }}>
        Vue Agrégée — Analyse
      </h1>
      <div style={{
        display: "flex",
        gap: "0.5rem",
        flexWrap: "wrap",
        justifyContent: "center",
      }}>
        {Object.entries(filters).map(([key, val]) => (
          val && (
            <span key={key} style={{
              padding: "0.3rem 0.7rem",
              background: "#161d27",
              border: "1px solid #1e2a3a",
              borderRadius: "6px",
              fontSize: "0.8rem",
              color: "#8899aa",
            }}>
              {key}: <strong style={{ color: "#e8ecf1" }}>{val}</strong>
            </span>
          )
        ))}
      </div>
      <p style={{ color: "#8899aa", fontSize: "0.9rem" }}>
        Les graphiques seront implémentés au Prompt 7.3
      </p>
      <Link to="/" style={{
        color: "#3d7aed",
        textDecoration: "none",
        fontSize: "0.88rem",
        fontWeight: 500,
      }}>
        ← Retour à la sélection
      </Link>
    </div>
  );
}
